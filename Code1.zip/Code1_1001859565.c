/* Coding Assignment 1 */
/* Abhisek Kumar Jha 1001859565*/
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <time.h>

typedef struct node
{
	int number;
	struct node *next_ptr;
}
NODE;


void AddNodeToLL(int Number, NODE **LinkedListHead)
{
    

    NODE *temp, *cur;

    //creating a new node
    temp =  malloc(sizeof(NODE));
    temp->number = Number;
    temp->next_ptr= NULL;

    cur = *LinkedListHead;

	if (cur == NULL)
	{
        //then no head exists yet, so set temp as head
		*LinkedListHead = temp;
	}
	else
	{
        //find end of the current list
		while(cur->next_ptr!=NULL)
		{
			cur=cur->next_ptr;
            //curr is now the last node in the list
		}
		cur->next_ptr=temp;
	}

}

void ReadFileIntoLL(int argc,  char *argv[], NODE **LLH)
{
    
    if(argc<=1)
    {
        printf("File must be provided on command line...exiting\n");
        exit(0);
    }
    else
    {
        FILE *filename =NULL;
        filename= fopen(argv[1], "r");
        char InsideFile[200];
        int FileNum;
        int count = 0, sum =0;

        while(fgets(InsideFile, sizeof(InsideFile)-1 ,filename))
        {
            FileNum= atoi(InsideFile);

            AddNodeToLL(FileNum, LLH);
            
            sum= sum+FileNum;
            count++;
        }
        printf("\n\n%d records were read for total sum of %d\n",count, sum);
    }
  
       
}

void PrintLL(NODE *LLH) 
{ 
    NODE *TempPtr=NULL;
    TempPtr= LLH;

    while(TempPtr != NULL)
    {
        printf("\n%p\t\t%d\t\t%p\n",TempPtr,TempPtr->number, TempPtr->next_ptr);
		TempPtr=TempPtr->next_ptr;
    
    }
    
}

void FreeLL(NODE **LLH) 
{ 
    {
	NODE *TempPtr= NULL, *next_ptr= NULL;
	TempPtr =*LLH;
	int CNT=0, Total=0;
	
	while(TempPtr!=NULL)
	{
		Total = Total + TempPtr->number;
		next_ptr=TempPtr->next_ptr;

		#ifdef PRINT
		printf("\nFreeing %p %d %p\n",TempPtr, TempPtr->number,TempPtr->next_ptr);
		#endif

		free(TempPtr);
		CNT++;
		TempPtr= next_ptr;
	}
	printf("\n%d nodes were deleted for a total sum of %d\n", CNT, Total);
}

}

int main(int argc, char *argv[]) 
{ 
	NODE *LLH = NULL;

    clock_t start, end;

	start=clock();
	ReadFileIntoLL(argc, argv, &LLH);
	end=clock();
	printf("\n%ld tics to write the file into the linked list\n", end-start);

	#ifdef PRINT
	start= clock();

	PrintLL(LLH);
	end=clock();

	printf("\n%ld tics to print the linked list\n", end-start);
	#endif

	start=clock();
	FreeLL(&LLH);
	
	end=clock();
	printf("\n%ld tics to free the linked list\n", end-start);


	return 0;
   
} 
